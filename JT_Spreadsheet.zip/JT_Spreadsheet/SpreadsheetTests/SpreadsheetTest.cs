﻿using SS;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using SpreadsheetUtilities;

namespace SpreadsheetTests
{
    
    
    /// <summary>
    ///This is a test class for SpreadsheetTest and is intended
    ///to contain all SpreadsheetTest Unit Tests
    ///</summary>
    [TestClass()]
    public class SpreadsheetTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for Spreadsheet Constructor
        ///</summary>
        [TestMethod()]
        public void SpreadsheetConstructorTest1()
        {
            Func<string, bool> validity = null; // TODO: Initialize to an appropriate value
            Func<string, string> normalization = null; // TODO: Initialize to an appropriate value
            string versionNumber = string.Empty; // TODO: Initialize to an appropriate value
            Spreadsheet target = new Spreadsheet(validity, normalization, versionNumber);
            Assert.Inconclusive("TODO: Implement code to verify target");
        }


        /// <summary>
        ///A test for GetCellContents
        ///</summary>
        [TestMethod()]
        public void GetCellContentsTest()
        {
            Spreadsheet s = new Spreadsheet();
            string name = "A1";
            object expected = "HELLO";
            object actual;
            s.SetContentsOfCell("A1", "hello");
            actual = s.GetCellContents(name);
            Assert.AreEqual(expected, actual);

            name = "A1";
            expected = "GOODBYE";
            s.SetContentsOfCell("A1", "GooDBye");
            actual = s.GetCellContents(name);
            Assert.AreEqual(expected, actual);

            name = "A2";
            expected = 2.0;
            s.SetContentsOfCell("A2", "2");
            actual = s.GetCellContents(name);
            Assert.AreEqual(expected, actual);

            name = "A3";
            expected = 4.0;
            s.SetContentsOfCell("A3", "=A2+2");
            actual = s.GetCellValue(name);
            Assert.AreEqual(expected, actual);

            name = "A3";
            expected = "A2+2";
            s.SetContentsOfCell("A3", "=A2+2");
            actual = s.GetCellContents(name).ToString();
            Assert.AreEqual(expected, actual);

            name = "A3";
            expected = "OVERRIDEFORMULA";
            s.SetContentsOfCell("A3", "overrideFormula");
            actual = s.GetCellContents(name);
            Assert.AreEqual(expected, actual);

            name = "A3";
            expected = "OVERRIDEFORMULA";
            s.SetContentsOfCell("A3", "");
            actual = s.GetCellContents(name);
            Assert.AreEqual(expected, actual);
        }



        /// <summary>
        ///A test for Save and GetSaved
        ///</summary>
        [TestMethod()]
        public void SaveTest()
        {
            Spreadsheet s = new Spreadsheet();
            s.SetContentsOfCell("A0", "2");
            s.SetContentsOfCell("A1", "=A0");
            s.SetContentsOfCell("A2", "hello");
            string filename = "C:/Users/JT/Documents/Visual Studio 2010/Projects/PS5/xmlSaveTest1.xml";
            s.Save(filename);

            Spreadsheet s2 = new Spreadsheet("C:/Users/JT/Documents/Visual Studio 2010/Projects/PS5/xmlSaveTest1.xml", s.IsValid, s.Normalize, "default");

            foreach (String name in s.GetNamesOfAllNonemptyCells()) {
                Assert.AreEqual(s.GetCellValue(name), s2.GetCellValue(name));
            }
        }


        /// <summary>
        ///A test for isName
        ///</summary>
        [TestMethod()]
        [DeploymentItem("Spreadsheet.dll")]
        public void isNameTest()
        {
            string token = "";
            bool expected = false;
            bool actual;
            actual = Spreadsheet_Accessor.isName(token);
            Assert.AreEqual(expected, actual);

            token = "a_";
            expected = false;
            actual = Spreadsheet_Accessor.isName(token);
            Assert.AreEqual(expected, actual);

            token = "4";
            expected = false;
            actual = Spreadsheet_Accessor.isName(token);
            Assert.AreEqual(expected, actual);

            token = null;
            expected = false;
            actual = Spreadsheet_Accessor.isName(token);
            Assert.AreEqual(expected, actual);

            token = "aAnfjh3349";
            expected = true;
            actual = Spreadsheet_Accessor.isName(token);
            Assert.AreEqual(expected, actual);

            token = "abc0123";
            expected = true;
            actual = Spreadsheet_Accessor.isName(token);
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        ///A test for normalizer
        ///</summary>
        [TestMethod()]
        [DeploymentItem("Spreadsheet.dll")]
        public void normalizerTest()
        {
            string name = "HeLLo";
            string expected = "HELLO";
            string actual;
            actual = Spreadsheet_Accessor.normalizer(name);
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        ///A test for varLookup
        ///</summary>
        [TestMethod()]
        [DeploymentItem("Spreadsheet.dll")]
        public void varLookupTest()
        {
            Spreadsheet_Accessor s = new Spreadsheet_Accessor();

            s.SetCellContents("A1", 2);
            string name = "A1";
            double expected = 2;
            double actual;
            actual = s.varLookup(name);
            Assert.AreEqual(expected, actual);

            s.SetCellContents("A2", new Formula("A1+4", s.IsValid, s.Normalize));
            name = "A2";
            expected = 6;
            actual = s.varLookup(name);
            Assert.AreEqual(expected, actual);

            s.SetCellContents("A3", new Formula("A2", s.IsValid, s.Normalize));
            name = "A3";
            expected = 6;
            actual = s.varLookup(name);
            Assert.AreEqual(expected, actual);

            s.SetCellContents("A2", 3.0);
            name = "A3";
            expected = 3.0;
            actual = s.varLookup(name);
            Assert.AreEqual(expected, actual);

            s.SetCellContents("a4", 3.000);
            name = "A4";
            expected = 3.0;
            actual = s.varLookup(name);
            Assert.AreEqual(expected, actual);

            s.SetCellContents("a5", new Formula("a1", s.IsValid, s.Normalize));
            name = "A5";
            expected = 2;
            actual = s.varLookup(name);
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        ///A test for Changed
        ///</summary>
        [TestMethod()]
        [DeploymentItem("Spreadsheet.dll")]
        public void ChangedTest()
        {
            Spreadsheet_Accessor target = new Spreadsheet_Accessor();
            bool expected = true;
            bool actual;
            target.SetCellContents("A1", 4);
            actual = target.Changed;
            Assert.AreEqual(expected, actual);
        }
    }
}
