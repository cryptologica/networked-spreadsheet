﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using SS;


namespace SpreadsheetGUI
{
    public partial class Form1 : Form
    {
        private Spreadsheet sp;
        private Dictionary<Int32, String> numLetters;
        private Dictionary<String, Int32> letterToNumbers;
        private String currentName;
        private String currFile;

        /// <summary>
        /// Constructor for the Form
        /// </summary>
        public Form1()
        {
            InitializeComponent();
            
            sp = new Spreadsheet(s=>true, s=>s.ToUpper(), "ps6");

            numLetters = new Dictionary<int, string>();
            String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            for (int i = 0; i < 26; i++) {
                numLetters.Add(i, alphabet.Substring(i,1));
            }

            letterToNumbers = new Dictionary<string, int>();
            for (int i = 0; i < 26; i++)
            {
                letterToNumbers.Add(alphabet.Substring(i, 1), i);
            }

            this.Text = "Spreadsheet" + (SpreadsheetGUI.DemoApplicationContext.getAppContext().getFormCount()+1).ToString();


            // This an example of registering a method so that it is notified when
            // an event happens.  The SelectionChanged event is declared with a
            // delegate that specifies that all methods that register with it must
            // take a SpreadsheetPanel as its parameter and return nothing.  So we
            // register the displaySelection method below.

            // This could also be done graphically in the designer, as has been
            // demonstrated in class.
            spreadsheetPanel1.SelectionChanged += displaySelection;
            spreadsheetPanel1.SetSelection(0, 0);
        }

        // Every time the selection changes, this method is called with the
        // Spreadsheet as its parameter.
        private void displaySelection(SpreadsheetPanel ss)
        {
            int row, col;
            String value;
            // Get selected Row and column
            ss.GetSelection(out col, out row);
            ss.GetValue(col, row, out value);
            // Save name of selected location
            currentName = numLetters[col] + (row+1).ToString() ;
            // Get name, value and contents and output to respective text boxes
            nameBox.Text = currentName;
            valueBox.Text = sp.GetCellValue(currentName).ToString();
            Object contents = sp.GetCellContents(currentName);
            if (contents.GetType() == typeof(SpreadsheetUtilities.Formula))
            {
                contentsBox.Text = "=" + contents.ToString();
            }
            else { 
                contentsBox.Text = contents.ToString();
            }
            contentsBox.Focus();
            contentsBox.SelectionStart = contentsBox.Text.Length;
        }

        // Deals with the New menu
        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Tell the application context to run the form on the same
            // thread as the other forms.
            DemoApplicationContext.getAppContext().RunForm(new Form1());
        }

        // Deals with the Close menu
        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        /// When user leaves the content box it takes given input and processes it.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void contentsBox_Leave(object sender, System.EventArgs e)
        {
            try {
            // Get selected Row and column
            int row, col;
            spreadsheetPanel1.GetSelection(out col, out row);

            String contents = contentsBox.Text;
            if (contents.StartsWith("=")) {
                contents = sp.Normalize(contents);
            }
            if (contents != "")
            {
            
                ISet<string> namesTochange = sp.SetContentsOfCell(currentName, contents);
                foreach (String cellName in namesTochange)
                {

                    String value = sp.GetCellValue(cellName).ToString();
                    if (value == "SpreadsheetUtilities.FormulaError")
                    {
                        spreadsheetPanel1.SetValue(letterToNumbers[cellName.Substring(0, 1)], Int32.Parse(cellName.Substring(1)) - 1, "Formula Error");
                    }
                    else
                    {
                        spreadsheetPanel1.SetValue(letterToNumbers[cellName.Substring(0, 1)], Int32.Parse(cellName.Substring(1)) - 1, value);
                    }
                }
                }
            }
            catch(CircularException){
                int row, col;
                spreadsheetPanel1.GetSelection(out col, out row);
                spreadsheetPanel1.SetValue(col,row, "Circular Error");
                //MessageBox.Show("Warning: Your change has caused a cell to reference itself.", "Error Message", MessageBoxButtons.OK);
                }
        }

        /// <summary>
        /// When "Del" key is pushed, deletes the content in that cell.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void contentsBox_KeyDown(object sender, KeyEventArgs e)
        {
            //bool wasError = false;
            int row, col;
            spreadsheetPanel1.GetSelection(out col, out row);

            if (e.KeyCode == Keys.Delete)
            {
                String curVal;
                spreadsheetPanel1.GetValue(col, row, out curVal);
                if (contentsBox.Text != "" && curVal != "") {
                    ISet<string> namesTochange = sp.SetContentsOfCell(currentName, "");
                    foreach (String cellName in namesTochange)
                    {
                        String value = sp.GetCellValue(cellName).ToString();
                        if (value == "SpreadsheetUtilities.FormulaError")
                        {
                            spreadsheetPanel1.SetValue(letterToNumbers[cellName.Substring(0,1)], Int32.Parse(cellName.Substring(1))-1, "Formula Error");
                            //wasError = true;
                        }
                        else
                        {
                            spreadsheetPanel1.SetValue(letterToNumbers[cellName.Substring(0, 1)], Int32.Parse(cellName.Substring(1))-1, value);
                        }
                    }
                }
                spreadsheetPanel1.SetValue(col, row, "");
                contentsBox.Text = "";
                //if (wasError) {
                //    MessageBox.Show("Warning: Your change has caused one or more cells to become invalid.", "Error Message", MessageBoxButtons.OK);
                //}
                e.Handled = true;
            }
        }

        private void quitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// If someone clicks "close", check to see if it has unsaved changes 
        /// and if so prompt and ask if they really want to exit.
        /// </summary>
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (this.sp.Changed)
            {
                if (MessageBox.Show("Do you really want to quit, all unsaved changes will be discarded?", "Exit", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
                {
                    e.Cancel = true;
                }
            }
        }

        /// <summary>
        /// Opens a particular file specified by the user.
        /// The old window will close before new one opens,
        /// but prompts user if unsaved changes are detected.
        /// </summary>
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Create an instance of the open file dialog box.
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            // Set filter options and filter index.
            openFileDialog1.Filter = "Spreadsheet Files (.ss)|*.ss|All Files (*.*)|*.*";

            // Call the ShowDialog method to show the dialog box.
            // Process input if the user clicked OK.
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                Form1 form2 = new Form1();
                String fileName = openFileDialog1.FileName;
                SpreadsheetGUI.DemoApplicationContext.getAppContext().RunForm(form2);
                this.Close();
                form2.sp = new Spreadsheet(fileName, s => true, s => s.ToUpper(), "ps6");
                form2.Text = fileName.Substring(fileName.LastIndexOf("\\")+1);
                form2.currFile = fileName;
                foreach (String cellName in form2.sp.GetNamesOfAllNonemptyCells()) {
                    form2.spreadsheetPanel1.SetValue(letterToNumbers[cellName.Substring(0, 1)], Int32.Parse(cellName.Substring(1)) - 1, form2.sp.GetCellValue(cellName).ToString());
                }
            }
        }

        /// <summary>
        /// Opens a new spreadsheet (in another window).
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void newToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form1 form3 = new Form1();
            SpreadsheetGUI.DemoApplicationContext.getAppContext().RunForm(form3);
        }

        /// <summary>
        /// Displays a help message for when the help menu item is clicked.
        /// </summary>
        private void helpManual10ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            String helpMsg = String.Format("Need help?\n \n Click on a cell in the spreadsheet then"+
            " enter a string, number or formula into the contents box. Press the tab key to submit your input." +
            " Note that all formulas must be preceded by an equal sign character. You can open, save and create new spreadsheets via the File menu.");

            MessageBox.Show(helpMsg, "Help Manual 1.0", MessageBoxButtons.OK);
        }


        /// <summary>
        /// "Save", saves to current file path and file name.
        /// If file wasn't opened or saved, opens save dialog prompt.
        /// </summary>
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (currFile == null)
            {
                MessageBox.Show("Did you not already open or save the current spreadsheet file? Please specify a valid save path and file name.", "Save Error", MessageBoxButtons.OK);
                this.saveToolStripMenuItem_Click_1(sender, e);
            }
            else {
                this.sp.Save(currFile);
            }
        }

        /// <summary>
        /// "Save As...", Prompts with save dialog and allows user to select where
        /// they wish to save and what to name the file.
        /// </summary>
        private void saveToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            SaveFileDialog saveDialog = new SaveFileDialog();
            saveDialog.OverwritePrompt = true;
            saveDialog.Filter = "Spreadsheet Files (.ss)|*.ss|All Files (*.*)|*.*";
            
            if (saveDialog.ShowDialog() == DialogResult.OK)
            {
                String fileName = saveDialog.FileName;
                this.sp.Save(fileName);
                this.Text = fileName.Substring(fileName.LastIndexOf("\\") + 1);
                this.currFile = fileName;
            }
        }

    }
}

       