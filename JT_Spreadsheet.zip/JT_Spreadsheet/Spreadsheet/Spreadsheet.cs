﻿//Implemented by JT Newsome, u0693375 for CS 3500, Sept. 2012

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SpreadsheetUtilities;
using System.Xml;


namespace SS
{
    /// <summary>
    /// A spreadsheet is structure which contains an infinite number of cells. 
    /// </summary>
    public class Spreadsheet : AbstractSpreadsheet
    {

        private Dictionary<String, Cell> spreadTable;
        private SpreadsheetUtilities.DependencyGraph dg;
        private Func<string, double> lookup;
        private bool isChanged;

        /// <summary>
        /// Constructs a new spreadsheet based on default version and restriction functions.
        /// </summary>
        public Spreadsheet()
            : base(isName, normalizer, "default")
        {
            this.spreadTable = new Dictionary<string, Cell>();
            this.dg = new DependencyGraph();
            this.lookup = varLookup;
            this.Changed = false;
        }

        /// <summary>
        /// Constructs a new spreadsheet with the given version and restriction functions (validity and normalization)
        /// </summary>
        public Spreadsheet(Func<string, bool> validity, Func<string, string> normalization, string versionNumber)
            : base(validity, normalization, versionNumber)
        {
            this.spreadTable = new Dictionary<string, Cell>();
            this.dg = new DependencyGraph();
            this.lookup = varLookup;
            this.Changed = false;
        }
        /// <summary>
        /// Constructs new spreadsheet given a file name and version number, restricted by the given validity and normalization functions.
        /// </summary>
        public Spreadsheet(string fileName, Func<string, bool> validity, Func<string, string> normalization, string versionNumber)
            : base(validity, normalization, versionNumber)
        {
            this.spreadTable = new Dictionary<string, Cell>();
            this.dg = new DependencyGraph();
            this.lookup = varLookup;
            GetSavedVersion(fileName);
            this.Changed = false;
        }

        /// <summary>
        /// True if this spreadsheet has been modified since it was created or saved                  
        /// (whichever happened most recently); false otherwise.
        /// </summary>
        public override bool Changed
        {
            get
            {
                return isChanged;
            }
            protected set
            {
                isChanged = value;
            }
        }

        /// <summary>
        /// If content is null, throws an ArgumentNullException.
        /// 
        /// Otherwise, if name is null or invalid, throws an InvalidNameException.
        /// 
        /// Otherwise, if content parses as a double, the contents of the named
        /// cell becomes that double.
        /// 
        /// Otherwise, if content begins with the character '=', an attempt is made
        /// to parse the remainder of content into a Formula f using the Formula
        /// constructor.  There are then three possibilities:
        /// 
        ///   (1) If the remainder of content cannot be parsed into a Formula, a 
        ///       SpreadsheetUtilities.FormulaFormatException is thrown.
        ///       
        ///   (2) Otherwise, if changing the contents of the named cell to be f
        ///       would cause a circular dependency, a CircularException is thrown.
        ///       
        ///   (3) Otherwise, the contents of the named cell becomes f.
        /// 
        /// Otherwise, the contents of the named cell becomes content.
        /// 
        /// If an exception is not thrown, the method returns a set consisting of
        /// name plus the names of all other cells whose value depends, directly
        /// or indirectly, on the named cell.
        /// 
        /// For example, if name is A1, B1 contains A1*2, and C1 contains B1+A1, the
        /// set {A1, B1, C1} is returned.
        /// </summary>
        public override ISet<string> SetContentsOfCell(string name, string content)
        {
            if (content == null)
            {
                throw new ArgumentNullException();
            }
            if (name == null)
            {
                throw new InvalidNameException();
            }

            name = this.Normalize(name);
            //content = this.Normalize(content);

            Double parsedDouble;
            if (Double.TryParse(content, out parsedDouble))
            {
                return this.SetCellContents(name, parsedDouble);
            }
            else if (content.StartsWith("="))
            {
                // Input substring, without "="
                content = this.Normalize(content);
                return this.SetCellContents(name, new Formula(content.Substring(1,content.Length-1), IsValid, Normalize));
            }
            else
            {
                return this.SetCellContents(name, content);
            }
        }


        /// <summary>
        /// If name is null or invalid, throws an InvalidNameException.
        /// 
        /// Otherwise, returns the value (as opposed to the contents) of the named cell.  The return
        /// value should be either a string, a double, or a SpreadsheetUtilities.FormulaError.
        /// </summary>
        public override object GetCellValue(string name)
        {
            if (name == null)
            {
                throw new InvalidNameException();
            }
            if (!IsValid(name))
            {
                throw new InvalidNameException();
            }
            Cell c;
            try { 
              c = this.spreadTable[name];  
            }
            catch(KeyNotFoundException){
                return "";
            }
            if (c.getContents().GetType() == typeof(Double))
            {
                return (double) c.getValue();
            }
            else if (c.getContents().GetType() == typeof(Formula))
            {
                return c.getValue();
            }
            else {
                // String or Formula Error, yes?
                return c.getValue();
            }
        }


        /// <summary>
        /// Returns the Version information of the spreadsheetg savd in the named file.
        /// If there are any problems opening, reading, or closing the file, the method
        /// should throw a SpreadsheetReadWriteException with an explanatory message.
        /// </summary>
        public override string GetSavedVersion(string filename)
        {
            try
            {
                using (XmlReader reader = XmlReader.Create(filename)) {
                    while (reader.Read())
                    {
                        if (reader.IsStartElement())
                        {
                            String newVersion;
                            String newContents;
                            String newName;

                            String attrib = reader.Name;

                            if(attrib == "spreadsheet"){
                                    newVersion = reader["version"];
                                    if (this.Version != newVersion) {
                                        throw new SpreadsheetReadWriteException("Error: version incompatibility.");
                                    }
                            }

                            if(attrib == "cell"){

                                    // Get its "name"
                                    reader.ReadToFollowing("name");
                                    newName = this.Normalize(reader.ReadElementString());
                                    //reader.Read();
                                    //reader.Read();
                                    //reader.Read();
                                    //newName = this.Normalize(reader.Value);
                                    if (!IsValid(newName)) {
                                        throw new SpreadsheetReadWriteException("Error: invalid name");
                                    }

                                    // Get next attrib ("contents") and process it
                                    //reader.Read();
                                    //reader.Read();
                                    //reader.Read();
                                    //reader.Read();
                                    newContents = reader.ReadElementString();
                                    this.SetContentsOfCell(newName, newContents);
                            }

                            if (attrib == "name") { 
                                
                            }

                        }
                    }
                }
            }
            catch
            {
                throw new SpreadsheetReadWriteException("Error when reading the file");
            }
                            return this.Version;
        }

        /// <summary>
        /// Writes the contents of this spreadsheet to the named file using an XML format.
        /// The XML elements should be structured as follows:
        /// 
        /// <spreadsheet version="version information goes here">
        /// 
        /// <cell>
        /// <name>
        /// cell name goes here
        /// </name>
        /// <contents>
        /// cell contents goes here
        /// </contents>    
        /// </cell>
        /// 
        /// </spreadsheet>
        /// 
        /// There should be one cell element for each non-empty cell in the spreadsheet.  
        /// If the cell contains a string, it should be written as the contents.  
        /// If the cell contains a double d, d.ToString() should be written as the contents.  
        /// If the cell contains a Formula f, f.ToString() with "=" prepended should be written as the contents.
        /// 
        /// If there are any problems opening, writing, or closing the file, the method should throw a
        /// SpreadsheetReadWriteException with an explanatory message.
        /// </summary>
        public override void Save(string filename)
        {
            try
            {
                using (XmlWriter writer = XmlWriter.Create(filename))
                {
                    writer.WriteStartDocument();

                    writer.WriteStartElement("spreadsheet");
                    writer.WriteAttributeString("version", this.Version);

                    // Iterate through and add each Cell, writing the name and contents
                    foreach (String keyName in GetNamesOfAllNonemptyCells())
                    {

                        Object contents = spreadTable[keyName].getContents();
                        Object objType = contents.GetType();

                        writer.WriteStartElement("cell");
                        writer.WriteStartElement("name");
                        writer.WriteString(spreadTable[keyName].getName());
                        writer.WriteEndElement();

                        writer.WriteStartElement("contents");

                        // Check contents type, then write accordingly
                        if (contents.GetType() == typeof(Formula))
                        {
                            writer.WriteString("="+contents.ToString());
                        }
                        else if (contents.GetType() == typeof(Double))
                        {
                            writer.WriteString(contents.ToString());
                        }
                        else
                        {
                            writer.WriteString(contents.ToString());
                        }

                        // </contents>
                        writer.WriteEndElement();
                        // </cell>
                        writer.WriteEndElement();
                    }

                    // </spreadsheet>
                    writer.WriteEndElement();

                    writer.WriteEndDocument();
                }
            }
            catch
            {
                throw new SpreadsheetReadWriteException("Error when saving file.");
            }
            this.Changed = false;
        }


        /// <summary>
        /// Enumerates the names of all the non-empty cells in the spreadsheet.
        /// </summary>
        public override IEnumerable<string> GetNamesOfAllNonemptyCells()
        {
            List<string> nonEmptyStr = new List<string>();
            foreach (Cell c in spreadTable.Values)
            {
                if (c.getContents() != null)
                {
                    nonEmptyStr.Add(c.getName());
                }
            }
            IEnumerable<string> namesOfNonEmpty = nonEmptyStr;
            return namesOfNonEmpty;
        }

        /// <summary>
        /// If name is null or invalid, throws an InvalidNameException.
        /// 
        /// Otherwise, returns the contents (as opposed to the value) of the named cell.  The return
        /// value should be either a string, a double, or a Formula.
        /// </summary>
        public override Object GetCellContents(string name)
        {
            if (name == null)
            {
                throw new InvalidNameException();
            }
            if (!IsValid(name))
            {
                throw new InvalidNameException();
            }

            name = this.Normalize(name);

            Cell cellContents;
            if (spreadTable.TryGetValue(name, out cellContents))
            {
                //if (cellContents.getContents() == null) { 
                //    return "";
                //}
                return cellContents.getContents();
            }
            else
            {
                return "";
            }
            //else {
            //    throw new InvalidNameException();
            //}
        }

        /// <summary>
        /// If name is null or invalid, throws an InvalidNameException.
        /// 
        /// Otherwise, the contents of the named cell becomes number.  The method returns a
        /// set consisting of name plus the names of all other cells whose value depends, 
        /// directly or indirectly, on the named cell.
        /// 
        /// For example, if name is A1, B1 contains A1*2, and C1 contains B1+A1, the
        /// set {A1, B1, C1} is returned.
        /// </summary>
        protected override ISet<string> SetCellContents(string name, double number)
        {
            if (name == null)
            {
                throw new InvalidNameException();
            }
            name = Normalize(name);

            //IEnumerable<string> cellRecalc = GetCellsToRecalculate(name);
            

            // If cell exists, alter it.
            if (spreadTable.ContainsKey(name))
            {
                // If old value was a formula, remove its dependencies, then replace with new (double) value
                if (spreadTable[name].getContents().GetType() == typeof(Formula))
                {
                    Formula x = (Formula)spreadTable[name].getContents();
                    foreach (String y in x.GetVariables(IsValid))
                    {
                        dg.RemoveDependency(name, y);
                    }
                }
                spreadTable[name].setContents(number, varLookup);
            }
            // Otherwise, create a new cell and add it.
            else
            {
                spreadTable.Add(name, new Cell(name, number, IsValid, varLookup, Normalize));
            }
            this.Changed = true;
            HashSet<string> cellsToRecalculate = getIndirectDependees(name);
            HashSet<string> namesToRevisit = new HashSet<string>();
            //foreach(String n in cellsToRecalculate){
            //    Object value = spreadTable[n].getValue();
            //    if (value.GetType() == typeof(FormulaError)) {
            //        namesToRevisit.Add(n);
            //    }
            //    if (value.GetType() == typeof(Formula)) {
            //        Formula formObj = (Formula)value;
            //        spreadTable[n].setContents(formObj, varLookup);
            //    }
            //}

            foreach (String p in cellsToRecalculate) {
                namesToRevisit.Add(p);
            }
            Boolean hasUpdated = false;
            HashSet<string> newList = new HashSet<string>();
            do
            {
                hasUpdated = false;
                foreach (String revisitName in namesToRevisit)
                {
                    Cell c = spreadTable[revisitName];
                    Object oldValue = c.getValue();
                    c.setContents(c.getContents(), varLookup);
                    Object evalValue = c.getValue();
                    if (evalValue.GetType() == typeof(Double) && oldValue.GetType() == typeof(Double))
                    {
                        Double old = (Double)oldValue;
                        Double val = (Double)evalValue;
                        if (old != val) {
                            hasUpdated = true;
                        }
                    }
                    else if (evalValue.GetType() == typeof(Double) && oldValue.GetType() == typeof(FormulaError)) {
                        hasUpdated = true;
                    }
                    newList.Add(revisitName);
                }
                namesToRevisit.Clear();
                foreach (String a in newList) {
                    namesToRevisit.Add(a);
                }
                newList.Clear();
            }
            while (hasUpdated == true);
            return cellsToRecalculate;
        }


        /// <summary>
        /// If text is null, throws an ArgumentNullException.
        /// 
        /// Otherwise, if name is null or invalid, throws an InvalidNameException.
        /// 
        /// Otherwise, the contents of the named cell becomes text.  The method returns a
        /// set consisting of name plus the names of all other cells whose value depends, 
        /// directly or indirectly, on the named cell.
        /// 
        /// For example, if name is A1, B1 contains A1*2, and C1 contains B1+A1, the
        /// set {A1, B1, C1} is returned.
        /// </summary>
        protected override ISet<string> SetCellContents(string name, string text)
        {
            HashSet<string> dependentCellNames = new HashSet<string>();
            dependentCellNames.Add(name);
            HashSet<string> indirectDependees = getIndirectDependees(name);
            if (text == null)
            {
                throw new ArgumentNullException();
            }

            bool exists = spreadTable.ContainsKey(name);

            if (text == "" && !exists)
            {
                return dependentCellNames;
            }

            name = Normalize(name);
            //text = Normalize(text);

            if (!IsValid(name))
            {
                throw new InvalidNameException();
            }

            // If cell exists, alter it.
            if (exists)
            {
                if (spreadTable[name].getContents().GetType() == typeof(Formula))
                {
                    Formula x = (Formula)spreadTable[name].getContents();
                    foreach (String y in x.GetVariables(IsValid))
                    {
                        dg.RemoveDependency(name, y);
                    }
                    foreach (String m in indirectDependees) {
                        spreadTable[m].setValueToFormulaError();
                    }
                }
                else if (spreadTable[name].getContents().GetType() == typeof(Double)) {
                    foreach (String m in indirectDependees)
                    {
                        spreadTable[m].setValueToFormulaError();
                    }
                }
                spreadTable[name].setContents(text, varLookup);
            }
            // Otherwise, create a new cell and add it.
            else
            {
                spreadTable.Add(name, new Cell(name, text, IsValid, varLookup, Normalize));
            }

            this.Changed = true;
            HashSet<string> cellsToRecalculate = indirectDependees;
            HashSet<string> namesToRevisit = new HashSet<string>();

            foreach (String p in cellsToRecalculate)
            {
                namesToRevisit.Add(p);
            }
            Boolean hasUpdated = false;
            HashSet<string> newList = new HashSet<string>();
            do
            {
                hasUpdated = false;
                foreach (String revisitName in namesToRevisit)
                {
                    Cell c = spreadTable[revisitName];
                    Object oldValue = c.getValue();
                    c.setContents(c.getContents(), varLookup);
                    Object evalValue = c.getValue();
                    if (evalValue.GetType() == typeof(Double) && oldValue.GetType() == typeof(Double))
                    {
                        Double old = (Double)oldValue;
                        Double val = (Double)evalValue;
                        if (old != val)
                        {
                            hasUpdated = true;
                        }
                    }
                    else if (evalValue.GetType() == typeof(Double) && oldValue.GetType() == typeof(FormulaError))
                    {
                        hasUpdated = true;
                    }
                    newList.Add(revisitName);
                }
                namesToRevisit.Clear();
                foreach (String a in newList)
                {
                    namesToRevisit.Add(a);
                }
                newList.Clear();
            }
            while (hasUpdated == true);
            return cellsToRecalculate;
        }

        /// <summary>
        /// If formula parameter is null, throws an ArgumentNullException.
        /// 
        /// Otherwise, if name is null or invalid, throws an InvalidNameException.
        /// 
        /// Otherwise, if changing the contents of the named cell to be the formula would cause a 
        /// circular dependency, throws a CircularException.
        /// 
        /// Otherwise, the contents of the named cell becomes formula.  The method returns a
        /// Set consisting of name plus the names of all other cells whose value depends,
        /// directly or indirectly, on the named cell.
        /// 
        /// For example, if name is A1, B1 contains A1*2, and C1 contains B1+A1, the
        /// set {A1, B1, C1} is returned.
        /// </summary>
        protected override ISet<string> SetCellContents(string name, Formula formula)
        {
            if (name == null)
            {
                throw new InvalidNameException();
            }

            try
            {
                if (formula.Equals(null))
                {
                    throw new ArgumentNullException();
                }
            }
            catch (NullReferenceException)
            {
                throw new ArgumentNullException();
            }

            name = Normalize(name);

            dg.ReplaceDependents(name, formula.GetVariables(IsValid));
            IEnumerable<string> recalculateCellsList = GetCellsToRecalculate(name);

            // If cell exists, alter it.
            if (spreadTable.ContainsKey(name))
            {
                spreadTable[name].setContents(formula, varLookup);
            }
            // Otherwise, create a new cell and add it.
            else
            {
                spreadTable.Add(name, new Cell(name, formula, IsValid, varLookup, Normalize));
            }

            this.Changed = true;
            HashSet<string> cellsToRecalculate = getIndirectDependees(name);
            HashSet<string> namesToRevisit = new HashSet<string>();

            foreach (String p in cellsToRecalculate)
            {
                namesToRevisit.Add(p);
            }
            Boolean hasUpdated = false;
            HashSet<string> newList = new HashSet<string>();
            do
            {
                hasUpdated = false;
                foreach (String revisitName in namesToRevisit)
                {
                    Cell c = spreadTable[revisitName];
                    Object oldValue = c.getValue();
                    c.setContents(c.getContents(), varLookup);
                    Object evalValue = c.getValue();
                    if (evalValue.GetType() == typeof(Double) && oldValue.GetType() == typeof(Double))
                    {
                        Double old = (Double)oldValue;
                        Double val = (Double)evalValue;
                        if (old != val)
                        {
                            hasUpdated = true;
                        }
                    }
                    else if (evalValue.GetType() == typeof(Double) && oldValue.GetType() == typeof(FormulaError))
                    {
                        hasUpdated = true;
                    }
                    newList.Add(revisitName);
                }
                namesToRevisit.Clear();
                foreach (String a in newList)
                {
                    namesToRevisit.Add(a);
                }
                newList.Clear();
            }
            while (hasUpdated == true);
            return cellsToRecalculate;
        }

        /// <summary>
        /// Finds all the indirect dependees of given a name.
        /// For example, if name = A1 and B1 = "A1*2" and C1 = "B1+A1", then
        /// the set {A1, B1, C1} is returned.
        /// </summary>
        /// <param name="name">String name to find all indirect dependees of.</param>
        /// <returns>String HashSet of indirect dependees.</returns>
        private HashSet<string> getIndirectDependees(String name)
        {
            HashSet<string> dependeeCellNames = new HashSet<string>();
            HashSet<string> dependees = new HashSet<string>();
            dependeeCellNames.Add(name);
            Queue<string> q = new Queue<string>();
            q.Enqueue(name);
            while (q.Count != 0)
            {
                if (dg.HasDependees(q.Peek()))
                {
                    dependees = (HashSet<string>)dg.GetDependees(q.Dequeue());
                    if (dependees.Contains(name)) {
                        dependees.Remove(name);
                    }
                    foreach (String x in dependees)
                    {
                        q.Enqueue(x);
                        dependeeCellNames.Add(x);
                    }
                }
                else
                {
                    q.Dequeue();
                }
            }
            //dependeeCellNames.Reverse<string>();
            return dependeeCellNames;
        }


        /// <summary>
        /// If name is null, throws an ArgumentNullException.
        /// 
        /// Otherwise, if name isn't a valid cell name, throws an InvalidNameException.
        /// 
        /// Otherwise, returns an enumeration, without duplicates, of the names of all cells whose
        /// values depend directly on the value of the named cell.  In other words, returns
        /// an enumeration, without duplicates, of the names of all cells that contain
        /// formulas containing name.
        /// 
        /// For example, suppose that
        /// A1 contains 3
        /// B1 contains the formula A1 * A1
        /// C1 contains the formula B1 + A1
        /// D1 contains the formula B1 - C1
        /// The direct dependents of A1 are B1 and C1
        /// </summary>
        protected override IEnumerable<string> GetDirectDependents(string name)
        {
            if (name == null)
            {
                throw new ArgumentException();
            }
            return dg.GetDependents(name);
        }


        //private double getCellValue(String variable)
        //{
        //    Cell varCell;
        //    if (this.spreadTable.TryGetValue(variable, out varCell))
        //    {
        //        Object value = varCell.getValue();
        //        if (value.GetType() == typeof(Double))
        //        {
        //            return (Double)value;
        //        }
        //        else
        //        {
        //            throw new ArgumentException("Cell did not contain a double, the value for the variable.");
        //        }
        //    }
        //    else
        //    {
        //        throw new ArgumentException("Cell does not exist.");
        //    }
        //}


        private class Cell
        {
            private String _name;
            private Object _value;
            private Object _contents;

            public Cell(String name, Object contents, Func<string, bool> isValid, Func<string, double> lookup, Func<string, string> normalize)
            {
                if (!isValid(name))
                {
                    throw new InvalidNameException();
                }
                if (contents == null)
                {
                    throw new ArgumentNullException();
                }

                this._name = normalize(name);

                // If obj is a Formula, then evaluate and set its value
                Object objType = contents.GetType();
                if (contents.GetType() == typeof(Formula))
                {
                    Formula formObj = (Formula)contents;
                    this._value = formObj.Evaluate(lookup);
                    this._contents = formObj;
                }
                else if (contents.GetType() == typeof(double))
                {
                    this._value = (double)contents;
                    this._contents = (double)contents;
                }
                else if (contents.GetType() == typeof(string))
                {
                    this._contents = (string)contents;
                    this._value = (string)contents;
                }
                else
                {
                    throw new ArgumentException("Object type not supported.");
                }
            }

            public String getName()
            {
                return this._name;
            }

            public Object getContents()
            {
                return this._contents;
            }

            public Object getValue() {
                return this._value;
            }

            public void setContents(Object contents, Func<string, double> lookup)
            {
                Object objType = contents.GetType();
                if (contents.GetType() == typeof(Formula))
                {
                    Formula formObj = (Formula)contents;
                    this._contents = formObj;
                    this._value = formObj.Evaluate(lookup);
                }
                else if (contents.GetType() == typeof(double))
                {
                    this._contents = (double)contents;
                    this._value = (double)contents;
                }
                else if (contents.GetType() == typeof(string))
                {
                    this._contents = (string) contents;
                    this._value = (string)contents;
                }
                else {
                    //throw new ArgumentException("Object type not supported.");
                }
            }

            public void reset() {
                this._value = "";
                this._contents = "";
            }

            public void setValueToFormulaError() {
                this._value = new FormulaError();
            }

            /// <summary>
            /// Overrides Equals method so that Cells are compared only by name.
            /// </summary>
            public override bool Equals(object o)
            {
                if (o.GetType() != typeof(Cell))
                {
                    return false;
                }
                Cell cell = (Cell)o;
                if (cell.getName().Equals(this.getName()))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            /// <summary>
            /// Overrides GetHashCode
            /// </summary>
            public override int GetHashCode()
            {
                return this.GetHashCode();
            }

        } // End Cell Class
       

        private double varLookup(String name) {
            Object value;
            try { 
                value = this.spreadTable[name].getValue(); 
            }
            catch(KeyNotFoundException){
                throw new ArgumentException("Variable does not exist.");
            }
            if (value.GetType() == typeof(Double))
            {
                return (double) value;
            }
            else
            {
                throw new ArgumentException("Error on variable lookup.");
            }
        }

        private static string normalizer(string name)
        {
            return name;
        }

        /// <summary>
        /// Returns true if input string is a valid name.
        /// </summary>
        private static bool isName(String token)
        {
            if (token == null || token == "")
            {
                return false;
            }
            char[] arr = token.ToCharArray();
            bool startDoubles = false;

            for (int i = 0; i < arr.Length; i++)
            {
                char charToken = Char.ToLower(arr[i]);
                double number;
                bool isDouble = Double.TryParse(arr[i].ToString(), out number);
                //Enters only once
                if (isDouble && !startDoubles)
                {
                    startDoubles = true;
                    //If we have started doubles and still on first char of token, return false.
                    if (i == 0)
                    {
                        return false;
                    }
                    //if (charToken == '0')
                    //{
                    //    return false;
                    //}
                }

                //If doubles have started, but we get a char (not a double) return false.
                if (startDoubles && !isDouble)
                {
                    return false;
                }
            }

            // If never started doubles, return false. Should be at least one number
            if (!startDoubles)
            {
                return false;
            }
            return true;
        }

    }
}
